import socket

clientSocket=socket.socket(socket.AF_INET,socket.SOCK_STREAM)

hostname=socket.gethostname()
port=12345

clientSocket.connect((hostname,port))

print("Connection Established")

arr=[]

print("Enter 5 Numbers in array")
for i in range(0,5):
    temp=int(input())
    arr.append(temp)

clientSocket.send(str(arr).encode())

recvEvenSum=clientSocket.recv(1024)
recvOddSum=clientSocket.recv(1024)

print("Even Sum is ",end="")
print(recvEvenSum.decode())
print("Odd Sum is ",end="")
print(recvOddSum.decode())