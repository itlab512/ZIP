import fileinput
curr=None
maxPop=-1
lifeExp=-1
for line in fileinput.input():
    data=line.strip().split('\t')
    country,pop,exp=data
    if curr and curr!=country:
        print("%-30s %-10s %-5s" %(curr,maxPop,lifeExp))
        maxPop=-1
        lifeExp=-1
    curr=country
    if float(pop)>maxPop:
        maxPop=float(pop)
        lifeExp=float(exp)
if curr: print("%-30s %-10s %-5s" %(curr,maxPop,lifeExp))