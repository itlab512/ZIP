import sys
import pandas as pd
df=pd.read_csv('countries_exam.csv')
df=df.dropna()
words1=list(df['Country'].values)
words2=list(df['Population'].values)
words3=list(df['Life expectancy '].values)
for (word1,word2,word3) in zip(words1,words2,words3):
    print("%s\t%s\t%s" %(word1,word2,word3))