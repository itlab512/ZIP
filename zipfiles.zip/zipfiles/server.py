import socket
import ast
serverSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

hostname = socket.gethostname()
port = 12345

serverSocket.bind((hostname, port))
serverSocket.listen(5)

conn, addr = serverSocket.accept()
print("Server is Running")

arr = conn.recv(1024)
arr = ast.literal_eval(arr.decode())
evenSum = 0
oddSum = 0
for i in arr:
    temp = i
    sum = 0
    while temp != 0:
        d = temp % 10
        sum = sum+d
        temp = temp/10
    if int(sum) % 2 == 0:
        evenSum += int(sum)
    else:
        oddSum += int(sum)

conn.send(str(evenSum).encode())
conn.send(str(oddSum).encode())
